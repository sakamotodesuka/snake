#include"SNAKE.h"

SNAKE::SNAKE(){
	op_dir = 'a';
	Nnode = 0;
	head = Point(27, 27);
}